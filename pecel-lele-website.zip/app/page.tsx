import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { MapPin, Phone, ExternalLink, Clock } from "lucide-react"

export default function Home() {
  const menuItems = [
    { name: "Pecel Lele + Nasi", price: "Rp 19.000", description: "Lele kremes dengan nasi hangat" },
    { name: "Pecel Ayam + Nasi", price: "Rp 22.000", description: "Ayam kremes dengan nasi hangat" },
    { name: "Lele Saja", price: "Rp 14.000", description: "Lele kremes tanpa nasi" },
    { name: "Ayam Saja", price: "Rp 18.000", description: "Ayam kremes tanpa nasi" },
    { name: "Tahu", price: "Rp 2.000", description: "Tahu goreng renyah" },
    { name: "Tempe", price: "Rp 1.000", description: "Tempe goreng renyah" },
  ]

  const waNumber = "6281588041570"
  const locationUrl =
    "https://www.google.com/maps/search/?api=1&query=Jl.+Rancho+Indah+No.68+RT.2+RW.2+Tj.+Bar.+Kec.+Jagakarsa+Kota+Jakarta+Selatan+DKI+Jakarta+12530"
  const gofoodUrl = "https://gofood.link/a/GwvuZAG"

  return (
    <main className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-primary/20 via-accent/10 to-background py-20 px-4 animate-fade-in">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center space-y-6">
            <h1 className="text-5xl md:text-7xl font-bold text-balance text-foreground">Pecel Lele Kremes</h1>
            <p className="text-3xl md:text-4xl font-semibold text-primary">Pak De Nardi</p>
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto text-pretty leading-relaxed">
              Pecel lele kremes dengan cita rasa autentik, digoreng renyah dengan bumbu khas yang menggugah selera.
              Warung favorit keluarga Jakarta Selatan!
            </p>
            <div className="flex items-center justify-center gap-2 text-base md:text-lg text-foreground bg-card/80 backdrop-blur-sm py-3 px-6 rounded-lg inline-block mx-auto shadow-sm">
              <Clock className="size-5 text-primary" />
              <span className="font-semibold">Buka Setiap Hari: 18:00 - 00:00</span>
            </div>
            <div className="flex flex-wrap gap-4 justify-center pt-4">
              <Button asChild size="lg" className="gap-2 shadow-lg hover:shadow-xl transition-all duration-300">
                <a href={`https://wa.me/${waNumber}`} target="_blank" rel="noopener noreferrer">
                  <Phone className="size-5" />
                  Hubungi via WhatsApp
                </a>
              </Button>
              <Button
                asChild
                size="lg"
                variant="secondary"
                className="gap-2 shadow-lg hover:shadow-xl transition-all duration-300"
              >
                <a href={gofoodUrl} target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="size-5" />
                  Pesan GoFood
                </a>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Menu Section */}
      <section className="py-16 px-4 animate-slide-up">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold mb-4 text-balance">Daftar Menu</h2>
            <p className="text-lg text-muted-foreground text-pretty">Pilihan menu lezat dengan harga terjangkau</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {menuItems.map((item, index) => (
              <Card
                key={index}
                className="hover:shadow-lg transition-all duration-300 hover:-translate-y-1 border-2 hover:border-primary/50 animate-scale-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <CardHeader>
                  <CardTitle className="text-2xl text-foreground">{item.name}</CardTitle>
                  <CardDescription className="text-base">{item.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-primary">{item.price}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* About Us Section */}
      <section className="py-16 px-4 bg-muted/30">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-balance">Tentang Kami</h2>
          </div>

          <Card className="shadow-xl border-2">
            <CardHeader>
              <CardTitle className="text-2xl">Pecel Lele Kremes Pak De Nardi</CardTitle>
              <CardDescription className="text-base">
                Warung pecel lele dengan cita rasa rumahan sejak lama
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 text-base leading-relaxed">
              <p>
                Kami adalah warung pecel lele yang telah melayani masyarakat Jakarta Selatan dengan menu pecel lele
                kremes yang lezat dan terjangkau. Setiap hidangan kami dibuat dengan bahan-bahan segar dan bumbu pilihan
                yang khas.
              </p>
              <p>
                Pecel lele kami digoreng dengan tepung kremes yang renyah, disajikan dengan sambal terasi pedas, lalapan
                segar, dan nasi hangat. Cocok untuk makan malam bersama keluarga atau teman.
              </p>
              <div className="flex items-start gap-3 bg-primary/10 p-4 rounded-lg">
                <Clock className="size-6 text-primary flex-shrink-0 mt-1" />
                <div>
                  <p className="font-semibold text-primary text-lg">Jam Operasional</p>
                  <p className="text-foreground">
                    Buka setiap hari dari pukul <span className="font-bold">18:00 hingga 00:00 (tengah malam)</span>
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">Melayani Anda dengan sepenuh hati!</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Location & Contact Section */}
      <section className="py-16 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold mb-4 text-balance">Lokasi & Kontak</h2>
            <p className="text-lg text-muted-foreground text-pretty">Kunjungi kami atau hubungi untuk pemesanan</p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <Card className="shadow-lg border-2 hover:shadow-xl transition-shadow duration-300">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="size-5 text-primary" />
                  Alamat Kami
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-base leading-relaxed">
                  Jl. Rancho Indah No.68, RT.2/RW.2, Tj. Bar., Kec. Jagakarsa, Kota Jakarta Selatan, DKI Jakarta 12530
                </p>
                <Button asChild className="w-full gap-2 shadow-md hover:shadow-lg transition-all duration-300">
                  <a href={locationUrl} target="_blank" rel="noopener noreferrer">
                    <MapPin className="size-4" />
                    Buka di Google Maps
                  </a>
                </Button>
              </CardContent>
            </Card>

            <Card className="shadow-lg border-2 hover:shadow-xl transition-shadow duration-300">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Phone className="size-5 text-primary" />
                  Hubungi Kami
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">WhatsApp</p>
                  <p className="text-lg font-semibold">+62 815-8804-157</p>
                </div>
                <Button asChild className="w-full gap-2 shadow-md hover:shadow-lg transition-all duration-300">
                  <a href={`https://wa.me/${waNumber}`} target="_blank" rel="noopener noreferrer">
                    <Phone className="size-4" />
                    Chat WhatsApp
                  </a>
                </Button>
                <Button
                  asChild
                  variant="secondary"
                  className="w-full gap-2 shadow-md hover:shadow-lg transition-all duration-300"
                >
                  <a href={gofoodUrl} target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="size-4" />
                    Pesan via GoFood
                  </a>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-muted/50 py-8 px-4 mt-16">
        <div className="container mx-auto max-w-6xl text-center space-y-2">
          <p className="text-lg font-semibold text-foreground">Pecel Lele Kremes Pak De Nardi</p>
          <p className="text-sm text-muted-foreground">Jl. Rancho Indah No.68, Jagakarsa, Jakarta Selatan</p>
          <p className="text-sm text-muted-foreground">Buka Setiap Hari: 18:00 - 00:00</p>
          <p className="text-muted-foreground mt-4">© 2025 Pecel Lele Kremes Pak De Nardi. All rights reserved.</p>
        </div>
      </footer>
    </main>
  )
}
